#!/usr/bin/env python3
"""Build a clean GitHub upload package for EEC app."""

from __future__ import annotations

import json
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parents[1]
DOMAIN = "ecoflow_energy_control"

RELEASE_FILES = (
    ".gitignore",
    "README.md",
    "hacs.json",
    "custom_components/ecoflow_energy_control/__init__.py",
    "custom_components/ecoflow_energy_control/button.py",
    "custom_components/ecoflow_energy_control/config_flow.py",
    "custom_components/ecoflow_energy_control/const.py",
    "custom_components/ecoflow_energy_control/coordinator.py",
    "custom_components/ecoflow_energy_control/health.py",
    "custom_components/ecoflow_energy_control/manifest.json",
    "custom_components/ecoflow_energy_control/number.py",
    "custom_components/ecoflow_energy_control/policy.py",
    "custom_components/ecoflow_energy_control/power.py",
    "custom_components/ecoflow_energy_control/select.py",
    "custom_components/ecoflow_energy_control/sensor.py",
    "custom_components/ecoflow_energy_control/services.yaml",
    "custom_components/ecoflow_energy_control/switch.py",
    "custom_components/ecoflow_energy_control/api/ecoflow.py",
    "custom_components/ecoflow_energy_control/api/homewizard.py",
    "custom_components/ecoflow_energy_control/api/prices.py",
    "custom_components/ecoflow_energy_control/api/sma_cloud.py",
    "custom_components/ecoflow_energy_control/api/weather.py",
    "custom_components/ecoflow_energy_control/translations/en.json",
    "custom_components/ecoflow_energy_control/translations/nl.json",
    "dashboards/ecoflow-energy-control.yaml",
    "dashboards/frontend-requirements.yaml",
    "docs/live-validatie.md",
    "docs/ontwikkeling.md",
    "docs/eec-app-ontwikkeling.pptx",
    "docs/presentation-src/slide-01.mjs",
    "docs/presentation-src/slide-02.mjs",
    "docs/presentation-src/slide-03.mjs",
    "docs/presentation-src/slide-04.mjs",
    "docs/presentation-src/slide-05.mjs",
    "docs/presentation-src/slide-06.mjs",
    "docs/presentation-src/slide-07.mjs",
    "docs/presentation-src/theme.mjs",
    "tools/ecoflow_api_tester/README.md",
    "tools/ecoflow_api_tester/index.html",
    "tools/ecoflow_api_tester/server.py",
    "tools/build_release_package.py",
    "tools/release_check.py",
)


def _version() -> str:
    manifest = json.loads(
        (ROOT / "custom_components" / DOMAIN / "manifest.json").read_text(
            encoding="utf-8"
        )
    )
    return str(manifest["version"])


def main() -> int:
    version = _version()
    output_dir = ROOT / "dist"
    output_dir.mkdir(exist_ok=True)
    package = output_dir / f"eec-app-{version}.zip"

    missing = [path for path in RELEASE_FILES if not (ROOT / path).exists()]
    if missing:
        print("EEC release package: ontbrekende bestanden")
        for path in missing:
            print(f"- {path}")
        return 1

    with zipfile.ZipFile(package, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for relative in RELEASE_FILES:
            path = ROOT / relative
            archive.write(path, relative)

    print(f"EEC release package: {package}")
    print(f"Bestanden: {len(RELEASE_FILES)}")
    print("Upload de inhoud van deze zip naar de root van de GitHub-repository.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
