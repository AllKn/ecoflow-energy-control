"""Coordinator and local control policy."""

from __future__ import annotations

from datetime import datetime as dt_datetime, timedelta
import logging
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator
from homeassistant.util import dt as dt_util

from .api.ecoflow import EcoFlowApiError, EcoFlowCloudClient, render_template_dict
from .api.homewizard import (
    read_homewizard_ha_history,
    read_homewizard_ha_meter,
    read_homewizard_meter,
)
from .api.prices import (
    current_price,
    energyzero_url,
    epexspot_url,
    epexprijzen_url,
    fetch_prices,
    price_bands,
    price_summary,
)
from .api.sma_cloud import read_sma_device
from .api.weather import fetch_open_meteo_solar
from .const import (
    CONF_ACCESS_KEY,
    CONF_BATTERIES,
    CONF_DRY_RUN,
    CONF_ECOFLOW_HOST,
    CONF_HOMEWIZARD_METERS,
    CONF_POWERSTREAMS,
    CONF_PRICE_INTERVAL,
    CONF_PRICE_INCL_VAT,
    CONF_PRICE_PROVIDER,
    CONF_PRICE_SOURCE,
    CONF_PRICE_SURCHARGE,
    CONF_PRICE_URL,
    CONF_SECRET_KEY,
    CONF_SMA_API_HOST,
    CONF_SMA_ENDPOINT,
    CONF_SMA_INVERTERS,
    CONF_SMA_PLANT_ID,
    CONF_SMA_TOKEN,
    CONF_SMART_PLUGS,
    CONF_WEATHER_CITY,
    DEFAULT_ECOFLOW_HOST,
    DEFAULT_POWERSTREAM_QUOTAS,
    DEFAULT_SMART_PLUG_SCHEDULE_ENABLED,
    DEFAULT_SMART_PLUG_SCHEDULE_OFF,
    DEFAULT_SMART_PLUG_SCHEDULE_ON,
    DEFAULT_PRICE_INTERVAL,
    DEFAULT_PRICE_INCL_VAT,
    DEFAULT_PRICE_PROVIDER,
    DEFAULT_PRICE_SOURCE,
    DEFAULT_PRICE_SURCHARGE,
    DEFAULT_SMA_API_HOST,
    DEFAULT_SMA_ENDPOINT,
    DEFAULT_SCAN_INTERVAL,
    DEFAULT_WEATHER_CITY,
    DOMAIN,
    HOMEWIZARD_ROLE_GRID_METER,
    HOMEWIZARD_ROLE_SOLAR_TOTAL,
    POWERSTREAM_STRATEGY_BUFFER_50,
    POWERSTREAM_STRATEGY_MIN_INTERVAL_SECONDS,
    POWERSTREAM_STRATEGY_SELF_USE,
    POWERSTREAM_STRATEGY_TRADING,
    STRATEGY_BUFFER_50,
    STRATEGY_EXPORT,
    STRATEGY_IDLE,
    STRATEGY_SELF_USE,
    WEATHER_CITIES,
)
from .power import normalize_homewizard_power_w, normalize_powerstream_watts
from .policy import best_scenario, powerstream_group_decision, scenario_is_actionable

_LOGGER = logging.getLogger(__name__)


class EcoFlowEnergyCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Collect data and apply local policy."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        self.hass = hass
        self.entry = entry
        self.settings = {**entry.data, **entry.options}
        self.session = async_get_clientsession(hass)
        self.ecoflow = EcoFlowCloudClient(
            self.session,
            self.settings.get(CONF_ECOFLOW_HOST, DEFAULT_ECOFLOW_HOST),
            self.settings[CONF_ACCESS_KEY],
            self.settings[CONF_SECRET_KEY],
        )
        self.strategy = STRATEGY_IDLE
        self.export_watts = 600
        self.self_use_watts = 0
        self.solar_plug_threshold_watts = 1200
        self.powerstream_targets: dict[str, int] = {}
        self.powerstream_strategies: dict[str, str] = {}
        self.smart_plug_last_state: dict[str, bool] = {}
        self.smart_plug_last_state_at: dict[str, str] = {}
        self._powerstream_last_strategy_set: dict[str, Any] = {}
        self._solar_scale_hint_w_per_m2: float = 0.0
        self.dry_run = bool(self.settings.get(CONF_DRY_RUN, True))
        self._scenario_last_update = dt_util.now()
        self._scenario_totals: dict[str, dict[str, float]] = {}
        self._scenario_periods = self._scenario_period_keys(self._scenario_last_update)
        super().__init__(
            hass,
            _LOGGER,
            name=DOMAIN,
            update_interval=timedelta(seconds=DEFAULT_SCAN_INTERVAL),
        )

    async def _async_update_data(self) -> dict[str, Any]:
        settings = {**self.entry.data, **self.entry.options}
        errors: dict[str, str] = {}
        previous = self.data or {}

        try:
            prices = await self._async_fetch_prices(settings)
        except Exception as err:  # noqa: BLE001
            _LOGGER.warning("Could not fetch electricity prices: %s", err)
            errors["prices"] = str(err)
            prices = previous.get("prices", [])
        price_now = current_price(prices, dt_util.now())
        bands = price_bands(prices)
        summary = price_summary(prices, dt_util.now())
        weather = {}
        try:
            weather = await self._async_fetch_weather(settings)
        except Exception as err:  # noqa: BLE001
            _LOGGER.warning("Could not fetch weather forecast: %s", err)
            errors["weather"] = str(err)

        batteries = {}
        for device in settings.get(CONF_BATTERIES, []):
            serial = device.get("serial")
            if not serial or "VUL_HIER" in serial:
                continue
            try:
                source = "selected"
                try:
                    response = await self.ecoflow.get_device_quotas(
                        serial, device.get("quotas")
                    )
                except Exception:  # noqa: BLE001
                    source = "all_after_selected_error"
                    response = await self.ecoflow.get_device_quotas(serial, None)
                values = _extract_values(response)
                if not values:
                    source = "all_after_empty_selected"
                    response = await self.ecoflow.get_device_quotas(serial, None)
                    values = _extract_values(response)
                elif _needs_battery_power_fallback(values):
                    source = "all_after_missing_power"
                    response = await self.ecoflow.get_device_quotas(serial, None)
                    all_values = _extract_values(response)
                    if all_values:
                        values = all_values
                batteries[serial] = {
                    "name": device.get("name", serial),
                    "response": response,
                    "values": values,
                    "quota_source": source,
                    "response_debug": _response_debug(response),
                }
            except Exception as err:  # noqa: BLE001
                errors[f"battery_{serial}"] = str(err)
                batteries[serial] = {"name": device.get("name", serial), "error": str(err)}

        configured_batteries = [
            item
            for item in settings.get(CONF_BATTERIES, [])
            if item.get("serial") and "VUL_HIER" not in str(item.get("serial"))
        ]
        powerstreams = {}
        for index, device in enumerate(settings.get(CONF_POWERSTREAMS, [])):
            serial = device.get("serial")
            if not serial or "VUL_HIER" in serial:
                continue
            battery_serial = device.get("battery_serial") or _fallback_battery_serial(
                configured_batteries, index
            )
            target_watts = float(self.powerstream_targets.get(serial, 0))
            try:
                try:
                    response = await self.ecoflow.get_device_quotas(
                        serial, device.get("quotas", DEFAULT_POWERSTREAM_QUOTAS)
                    )
                except Exception:  # noqa: BLE001
                    response = await self.ecoflow.get_device_quotas(serial, None)
                values = _extract_values(response)
                if not values:
                    response = await self.ecoflow.get_device_quotas(serial, None)
                    values = _extract_values(response)
                raw_target_watts, target_watts_source = _first_number_or_match_with_source(
                    values,
                    (
                        "permanentWatts",
                        "inv.outputWatts",
                        "invOutputWatts",
                        "invOutWatts",
                        "outputWatts",
                        "outputPower",
                        "gridOutputWatts",
                        "gridOutputPower",
                        "acOutputWatts",
                        "ac.outputWatts",
                    ),
                    target_watts,
                )
                target_watts = normalize_powerstream_watts(
                    raw_target_watts,
                    float(device.get("max_watts") or 0),
                )
                powerstreams[serial] = {
                    "name": device.get("name", serial),
                    "response": response,
                    "values": values,
                    "target_watts": target_watts,
                    "raw_target_watts": raw_target_watts,
                    "target_watts_source": target_watts_source,
                    "max_watts": float(device.get("max_watts") or 0),
                    "phase": device.get("phase", "l1"),
                    "battery_serial": battery_serial,
                    "battery_name": _battery_name(settings, battery_serial),
                    "battery_soc": _battery_soc_for_serial(batteries, battery_serial),
                    "battery_free_wh": _battery_free_wh_for_serial(
                        batteries, battery_serial, _battery_name(settings, battery_serial)
                    ),
                    "response_debug": _response_debug(response),
                }
            except Exception as err:  # noqa: BLE001
                errors[f"powerstream_{serial}"] = str(err)
                powerstreams[serial] = {
                    "name": device.get("name", serial),
                    "values": {},
                    "target_watts": target_watts,
                    "target_watts_source": "stored_target",
                    "max_watts": float(device.get("max_watts") or 0),
                    "phase": device.get("phase", "l1"),
                    "battery_serial": battery_serial,
                    "battery_name": _battery_name(settings, battery_serial),
                    "battery_soc": _battery_soc_for_serial(batteries, battery_serial),
                    "battery_free_wh": _battery_free_wh_for_serial(
                        batteries, battery_serial, _battery_name(settings, battery_serial)
                    ),
                    "error": str(err),
                }

        smart_plugs = {}
        forecast_solar_power = 0.0
        for device in settings.get(CONF_SMART_PLUGS, []):
            serial = device.get("serial")
            if not serial or "VUL_HIER" in serial:
                continue
            try:
                response = await self.ecoflow.get_device_quotas(
                    serial, device.get("quotas")
                )
                smart_plugs[serial] = {
                    "name": device.get("name", serial),
                    "forecast_solar_power": forecast_solar_power,
                    "schedule_enabled": device.get(
                        "schedule_enabled", DEFAULT_SMART_PLUG_SCHEDULE_ENABLED
                    ),
                    "schedule_on": device.get("schedule_on", DEFAULT_SMART_PLUG_SCHEDULE_ON),
                    "schedule_off": device.get(
                        "schedule_off", DEFAULT_SMART_PLUG_SCHEDULE_OFF
                    ),
                    "on_command": device.get("on_command", {}),
                    "off_command": device.get("off_command", {}),
                    "last_command": self.smart_plug_last_state.get(serial),
                    "last_command_at": self.smart_plug_last_state_at.get(serial),
                    "scheduled_state": self._smart_plug_scheduled_state(
                        device, dt_util.now()
                    ),
                    "response": response,
                    "values": _extract_values(response),
                    "charges": device.get("charges"),
                }
            except Exception as err:  # noqa: BLE001
                errors[f"smart_plug_{serial}"] = str(err)
                smart_plugs[serial] = {
                    "name": device.get("name", serial),
                    "forecast_solar_power": forecast_solar_power,
                    "schedule_enabled": device.get(
                        "schedule_enabled", DEFAULT_SMART_PLUG_SCHEDULE_ENABLED
                    ),
                    "schedule_on": device.get("schedule_on", DEFAULT_SMART_PLUG_SCHEDULE_ON),
                    "schedule_off": device.get(
                        "schedule_off", DEFAULT_SMART_PLUG_SCHEDULE_OFF
                    ),
                    "on_command": device.get("on_command", {}),
                    "off_command": device.get("off_command", {}),
                    "last_command": self.smart_plug_last_state.get(serial),
                    "last_command_at": self.smart_plug_last_state_at.get(serial),
                    "scheduled_state": self._smart_plug_scheduled_state(
                        device, dt_util.now()
                    ),
                    "values": {},
                    "charges": device.get("charges"),
                    "error": str(err),
                }

        inverters = {}
        sma_token = settings.get(CONF_SMA_TOKEN)
        sma_plant_id = settings.get(CONF_SMA_PLANT_ID)
        for item in settings.get(CONF_SMA_INVERTERS, []):
            device_id = item.get("device_id")
            if not sma_token or not sma_plant_id or not device_id:
                continue
            try:
                name = item.get("name", device_id)
                inverters[name] = await read_sma_device(
                    self.session,
                    settings.get(CONF_SMA_API_HOST, DEFAULT_SMA_API_HOST),
                    sma_token,
                    sma_plant_id,
                    item,
                    settings.get(CONF_SMA_ENDPOINT, DEFAULT_SMA_ENDPOINT),
                )
            except Exception as err:  # noqa: BLE001
                errors[f"sma_{device_id}"] = str(err)
                inverters[item.get("name", device_id)] = {
                    "available": False,
                    "error": str(err),
                }

        solar_power = sum(
            float(values.get("ac_power_w") or 0) for values in inverters.values()
        )
        homewizard_meters = {}
        homewizard_items = _coerce_homewizard_meters(
            settings.get(CONF_HOMEWIZARD_METERS, [])
        )
        homewizard_solar_power = 0.0
        homewizard_phase_power = {"l1": 0.0, "l2": 0.0, "l3": 0.0}
        homewizard_grid_power: float | None = None
        homewizard_grid_phase_power = {"l1": 0.0, "l2": 0.0, "l3": 0.0}
        for item in homewizard_items:
            source_id = item.get("host") or item.get("device_id")
            if not source_id:
                continue
            try:
                if item.get("source") == "homeassistant":
                    reading = read_homewizard_ha_meter(self.hass, item)
                    if reading.get("role") == HOMEWIZARD_ROLE_GRID_METER:
                        reading["history"] = await read_homewizard_ha_history(
                            self.hass, item
                        )
                else:
                    reading = await read_homewizard_meter(self.session, item)
                name = item.get("name", source_id)
                homewizard_meters[name] = reading
                if reading.get("role") == HOMEWIZARD_ROLE_SOLAR_TOTAL:
                    active_power = normalize_homewizard_power_w(
                        reading.get("active_power_w")
                    )
                    homewizard_solar_power += abs(active_power)
                    for phase, watts in reading.get("phase_power_w", {}).items():
                        homewizard_phase_power[phase] += abs(
                            normalize_homewizard_power_w(watts)
                        )
                elif reading.get("role") == HOMEWIZARD_ROLE_GRID_METER:
                    active_power = normalize_homewizard_power_w(
                        reading.get("active_power_w"), allow_deciwatts=False
                    )
                    if active_power is not None:
                        homewizard_grid_power = (
                            (homewizard_grid_power or 0.0) + active_power
                        )
                    for phase, watts in reading.get("phase_power_w", {}).items():
                        normalized = normalize_homewizard_power_w(
                            watts, allow_deciwatts=False
                        )
                        if normalized is not None:
                            homewizard_grid_phase_power[phase] += normalized
            except Exception as err:  # noqa: BLE001
                errors[f"homewizard_{source_id}"] = str(err)
                homewizard_meters[item.get("name", source_id)] = {
                    "available": False,
                    "error": str(err),
                }

        powerstream_export = self._tracked_powerstream_export(
            powerstreams=powerstreams
        )
        corrected_homewizard_solar = homewizard_solar_power - powerstream_export
        corrected_phase_power = {
            phase: watts
            - self._tracked_powerstream_export(phase, powerstreams=powerstreams)
            for phase, watts in homewizard_phase_power.items()
        }
        corrected_grid_power = homewizard_grid_power
        corrected_grid_phase_power = dict(homewizard_grid_phase_power)
        effective_solar_power = corrected_homewizard_solar if homewizard_meters else solar_power
        self._update_solar_scale_hint(weather, effective_solar_power)
        forecast_solar_power = self._forecast_solar_power_for_horizon(
            weather,
            effective_solar_power,
            dt_util.now(),
        )
        for serial, item in smart_plugs.items():
            if isinstance(item, dict):
                item["forecast_solar_power"] = forecast_solar_power
        for serial, item in powerstreams.items():
            strategy = self.powerstream_strategies.get(serial, POWERSTREAM_STRATEGY_SELF_USE)
            item["group_strategy"] = strategy
            item.update(
                powerstream_group_decision(
                    strategy,
                    item,
                    price_now,
                    bands,
                    effective_solar_power,
                )
            )
        await self._async_apply_group_strategies(
            powerstreams,
            price_now,
            bands,
            effective_solar_power,
            errors,
        )
        powerstream_export = self._tracked_powerstream_export(
            powerstreams=powerstreams
        )
        corrected_homewizard_solar = homewizard_solar_power - powerstream_export
        corrected_phase_power = {
            phase: watts
            - self._tracked_powerstream_export(phase, powerstreams=powerstreams)
            for phase, watts in homewizard_phase_power.items()
        }
        corrected_grid_power = homewizard_grid_power
        corrected_grid_phase_power = dict(homewizard_grid_phase_power)
        effective_solar_power = corrected_homewizard_solar if homewizard_meters else solar_power
        scenarios = self._simulate_scenarios(
            settings,
            price_now,
            bands,
            batteries,
            effective_solar_power,
            forecast_solar_power,
        )

        await self._async_apply_smart_plug_schedule_now(
            settings,
            effective_solar_power,
            forecast_solar_power,
        )

        return {
            "price_now": price_now,
            "price_bands": bands,
            "price_summary": summary,
            "prices": prices,
            "batteries": batteries,
            "powerstreams": powerstreams,
            "smart_plugs": smart_plugs,
            "inverters": inverters,
            "homewizard_meters": homewizard_meters,
            "solar_power": solar_power,
            "homewizard_solar_power": homewizard_solar_power,
            "powerstream_export_w": powerstream_export,
            "corrected_solar_power": effective_solar_power,
            "forecast_solar_power": forecast_solar_power,
            "corrected_phase_power": corrected_phase_power,
            "homewizard_grid_power": homewizard_grid_power,
            "corrected_grid_power": corrected_grid_power,
            "corrected_grid_phase_power": corrected_grid_phase_power,
            "weather": weather,
            "expected_savings_eur": _expected_savings(price_now, weather),
            "scenarios": scenarios,
            "strategy": self.strategy,
            "dry_run": self.dry_run,
            "last_action": previous.get("last_action"),
            "last_powerstream_command": previous.get("last_powerstream_command"),
            "last_powerstream_error": previous.get("last_powerstream_error"),
            "errors": errors,
            "status": "ok" if not errors else f"{len(errors)} bron(nen) met fout",
        }

    async def _async_fetch_weather(self, settings: dict[str, Any]) -> dict[str, Any]:
        city = settings.get(CONF_WEATHER_CITY, DEFAULT_WEATHER_CITY)
        latitude, longitude = WEATHER_CITIES.get(city, WEATHER_CITIES[DEFAULT_WEATHER_CITY])
        weather = await fetch_open_meteo_solar(self.session, latitude, longitude)
        weather["city"] = city
        weather["provider"] = "Open-Meteo"
        return weather

    def _forecast_solar_power_for_horizon(
        self,
        weather: dict[str, Any],
        current_solar_power_w: float,
        now: dt_datetime,
        horizon_hours: int = 4,
    ) -> float:
        hourly = weather.get("hourly") or []
        if not isinstance(hourly, list) or not hourly:
            return 0.0

        scale = self._solar_scale_per_m2(current_solar_power_w, weather)
        if scale <= 0:
            return 0.0

        horizon_start = now.replace(minute=0, second=0, microsecond=0)
        horizon_end = horizon_start + timedelta(hours=horizon_hours)
        forecast_values: list[float] = []
        for row in hourly:
            try:
                starts_at = dt_datetime.fromisoformat(str(row.get("start")))
            except (TypeError, ValueError):
                continue
            if not (horizon_start <= starts_at < horizon_end):
                continue
            value = row.get("shortwave_w_m2")
            try:
                watts_m2 = float(value)
            except (TypeError, ValueError):
                continue
            forecast_values.append(max(0.0, watts_m2))

        if not forecast_values:
            return 0.0

        average_shortwave = sum(forecast_values) / len(forecast_values)
        return round(max(0.0, average_shortwave * scale), 1)

    def _solar_scale_per_m2(self, current_solar_w: float, weather: dict[str, Any]) -> float:
        shortwave_now = float(weather.get("shortwave_w_m2") or 0.0)
        if shortwave_now > 0 and current_solar_w > 0:
            ratio = float(current_solar_w) / shortwave_now
            if 0.0 < ratio <= 20.0:
                return ratio
        if self._solar_scale_hint_w_per_m2 > 0:
            return self._solar_scale_hint_w_per_m2
        if shortwave_now > 0:
            return 0.0
        return 0.0

    def _update_solar_scale_hint(self, weather: dict[str, Any], current_solar_power_w: float) -> None:
        shortwave_now = float(weather.get("shortwave_w_m2") or 0.0)
        if shortwave_now <= 0:
            return

        if current_solar_power_w <= 0:
            return

        ratio = current_solar_power_w / shortwave_now
        if ratio <= 0 or ratio > 20:
            return

        if self._solar_scale_hint_w_per_m2 <= 0:
            self._solar_scale_hint_w_per_m2 = ratio
            return

        self._solar_scale_hint_w_per_m2 = (
            0.8 * self._solar_scale_hint_w_per_m2 + 0.2 * ratio
        )

    def _simulate_scenarios(
        self,
        settings: dict[str, Any],
        price_now: float | None,
        bands: dict[str, float | None],
        batteries: dict[str, Any],
        solar_power_w: float,
        forecast_solar_watts: float,
    ) -> dict[str, dict[str, Any]]:
        now = dt_util.now()
        elapsed_hours = max(
            0.0, min((now - self._scenario_last_update).total_seconds() / 3600, 1.0)
        )
        self._scenario_last_update = now
        periods = self._scenario_period_keys(now)
        if periods != self._scenario_periods:
            self._reset_changed_scenario_periods(periods)
            self._scenario_periods = periods

        price = float(price_now or 0)
        cheap = bands.get("cheap")
        expensive = bands.get("expensive")
        spread = max(0.0, float(expensive or price) - float(cheap or price))
        export_capacity_w = self._configured_powerstream_capacity(settings)
        battery_soc = _battery_min_soc(batteries)
        usable_export_w = export_capacity_w if battery_soc is None or battery_soc > 10 else 0.0
        buffer_export_w = export_capacity_w if battery_soc is None or battery_soc > 50 else 0.0
        solar_surplus_w = max(0.0, float(solar_power_w or 0))
        forecast_solar_w = max(0.0, float(forecast_solar_watts or 0))
        forecasted_solar_for_plug = max(solar_surplus_w, forecast_solar_w)
        can_charge_from_grid = forecast_solar_w < self.solar_plug_threshold_watts
        input_warnings = _scenario_input_warnings(price_now, cheap, expensive, battery_soc)

        simulated = {
            "self_use": self._scenario_result(
                label="Optimalisatie eigen gebruik",
                action="solar laden" if forecasted_solar_for_plug > 100 else "stand-by",
                power_w=min(forecasted_solar_for_plug, export_capacity_w),
                eur_per_hour=(
                    min(forecasted_solar_for_plug, export_capacity_w) / 1000
                )
                * max(price, spread),
                price=price,
                battery_soc=battery_soc,
                reason="netto zonopwek beschikbaar"
                if forecasted_solar_for_plug > 100
                else "geen bruikbare zonopwek",
                input_warnings=input_warnings,
            ),
            "trading": self._scenario_result(
                label="Handelen",
                action="terugleveren"
                if expensive is not None and price >= expensive and usable_export_w > 0
                else "laden"
                if cheap is not None and price <= cheap and can_charge_from_grid
                else "wachten",
                power_w=usable_export_w
                if expensive is not None and price >= expensive
                else -min(
                    forecasted_solar_for_plug if can_charge_from_grid else export_capacity_w,
                    export_capacity_w,
                )
                if cheap is not None and price <= cheap and can_charge_from_grid
                else 0.0,
                eur_per_hour=(usable_export_w / 1000) * price
                if expensive is not None and price >= expensive
                else -(min(forecasted_solar_for_plug, export_capacity_w) / 1000) * price
                if cheap is not None and price <= cheap and can_charge_from_grid
                else 0.0,
                price=price,
                battery_soc=battery_soc,
                reason="hoge prijs en accu boven minimum"
                if expensive is not None and price >= expensive and usable_export_w > 0
                else "lage prijs, laden voorbereiden"
                if cheap is not None and price <= cheap and can_charge_from_grid
                else "prijs niet laag of hoog genoeg",
                input_warnings=input_warnings,
            ),
            "buffer_50": self._scenario_result(
                label="Buffer 50%",
                action="terugleveren boven buffer"
                if buffer_export_w > 0 and expensive is not None and price >= expensive
                else "buffer bewaken",
                power_w=buffer_export_w if expensive is not None and price >= expensive else 0.0,
                eur_per_hour=(buffer_export_w / 1000) * price
                if expensive is not None and price >= expensive
                else 0.0,
                price=price,
                battery_soc=battery_soc,
                reason="hoge prijs en buffer blijft boven 50%"
                if buffer_export_w > 0 and expensive is not None and price >= expensive
                else "buffer wordt bewaakt",
                input_warnings=input_warnings,
            ),
        }

        for key, item in simulated.items():
            totals = self._scenario_totals.setdefault(
                key, {"day": 0.0, "week": 0.0, "month": 0.0}
            )
            delta = float(item["eur_per_hour"]) * elapsed_hours
            totals["day"] += delta
            totals["week"] += delta
            totals["month"] += delta
            item["day_eur"] = round(totals["day"], 4)
            item["week_eur"] = round(totals["week"], 4)
            item["month_eur"] = round(totals["month"], 4)
        return simulated

    def _scenario_result(
        self,
        label: str,
        action: str,
        power_w: float,
        eur_per_hour: float,
        price: float,
        battery_soc: float | None,
        reason: str,
        input_warnings: list[str] | None = None,
    ) -> dict[str, Any]:
        warnings = input_warnings or []
        return {
            "label": label,
            "action": action,
            "power_w": round(power_w, 1),
            "eur_per_hour": round(eur_per_hour, 4),
            "price_eur_kwh": price,
            "battery_soc": battery_soc,
            "reason": _scenario_reason(reason, warnings),
            "input_ready": not warnings,
            "input_warnings": warnings,
        }

    def _scenario_period_keys(self, now) -> dict[str, str]:
        return {
            "day": now.strftime("%Y-%m-%d"),
            "week": f"{now.isocalendar().year}-W{now.isocalendar().week:02d}",
            "month": now.strftime("%Y-%m"),
        }

    def _reset_changed_scenario_periods(self, periods: dict[str, str]) -> None:
        for key, totals in self._scenario_totals.items():
            for period, value in periods.items():
                if self._scenario_periods.get(period) != value:
                    totals[period] = 0.0

    def _configured_powerstream_capacity(self, settings: dict[str, Any]) -> float:
        capacity = 0.0
        for device in settings.get(CONF_POWERSTREAMS, []):
            try:
                capacity += float(device.get("max_watts") or 0)
            except (TypeError, ValueError):
                continue
        return capacity or float(self.export_watts or 0)

    async def async_set_powerstream_watts(
        self, serial: str, watts: int, source: str = "handmatig"
    ) -> None:
        """Set a PowerStream output target using configured command template."""
        device = self._powerstream(serial)
        watts = max(0, min(watts, int(device.get("max_watts", watts))))
        commands = _powerstream_command_candidates(device.get("command"), watts)
        self.powerstream_targets[serial] = watts
        base_data = self._with_powerstream_target(serial, watts, source)
        if self.dry_run:
            self.async_set_updated_data(
                {
                    **base_data,
                    "last_action": f"dry-run {source} {serial} -> {watts} W",
                    "last_powerstream_command": commands[0],
                }
            )
            return
        errors: list[str] = []
        used_command = commands[0]
        for command in commands:
            self.async_set_updated_data(
                {
                    **base_data,
                    "last_action": f"probeer {source} {serial} -> {watts} W",
                    "last_powerstream_command": command,
                    "last_powerstream_error": None,
                }
            )
            try:
                await self.ecoflow.set_device_command(serial, command)
            except EcoFlowApiError as err:
                errors.append(str(err))
                self.async_set_updated_data(
                    {
                        **base_data,
                        "last_action": f"{source} {serial} -> {watts} W mislukt",
                        "last_powerstream_command": command,
                        "last_powerstream_error": str(err),
                    }
                )
                if "1008" not in str(err):
                    raise
                continue
            used_command = command
            break
        else:
            raise EcoFlowApiError("; ".join(errors))
        self.async_set_updated_data(
            {
                **base_data,
                "last_action": f"{source} {serial} -> {watts} W",
                "last_powerstream_command": used_command,
                "last_powerstream_error": None,
            }
        )

    def set_powerstream_strategy(self, serial: str, strategy: str) -> None:
        self.powerstream_strategies[serial] = strategy

    def _can_update_powerstream_strategy(self, serial: str) -> bool:
        return self._powerstream_strategy_wait_seconds(serial) <= 0

    def _powerstream_strategy_wait_seconds(self, serial: str) -> int:
        last_update = self._powerstream_last_strategy_set.get(serial)
        if last_update is None:
            return 0
        elapsed = (dt_util.utcnow() - last_update).total_seconds()
        return max(0, int(POWERSTREAM_STRATEGY_MIN_INTERVAL_SECONDS - elapsed))

    async def _async_apply_group_strategies(
        self,
        powerstreams: dict[str, dict[str, Any]],
        price_now: float | None,
        bands: dict[str, float | None],
        solar_power: float,
        errors: dict[str, str],
        default_strategy: str = POWERSTREAM_STRATEGY_SELF_USE,
    ) -> None:
        for device in self.settings.get(CONF_POWERSTREAMS, []):
            serial = device.get("serial")
            if not serial or "VUL_HIER" in serial:
                continue
            item = powerstreams.get(serial, {})
            if not isinstance(item, dict):
                item = {}
            powerstreams[str(serial)] = item
            strategy = self.powerstream_strategies.get(str(serial), default_strategy)
            item["group_strategy"] = strategy
            decision = powerstream_group_decision(
                strategy, item, price_now, bands, solar_power
            )
            item.update(decision)
            desired = int(decision.get("suggested_watts") or 0)
            current = int(round(float(item.get("target_watts") or 0)))
            if strategy == "idle" or abs(desired - current) < 10:
                continue
            if not self._can_update_powerstream_strategy(serial):
                item["strategy_throttled"] = True
                item["strategy_next_update_seconds"] = self._powerstream_strategy_wait_seconds(
                    serial
                )
                continue
            try:
                used_command = await self._async_send_powerstream_watts(serial, desired)
            except Exception as err:  # noqa: BLE001
                errors[f"powerstream_strategy_{serial}"] = str(err)
                item["strategy_error"] = str(err)
                continue
            errors.pop(f"powerstream_strategy_{serial}", None)
            self._powerstream_last_strategy_set[serial] = dt_util.utcnow()
            self.powerstream_targets[serial] = desired
            item["target_watts"] = float(desired)
            item["raw_target_watts"] = float(desired * 10)
            item["target_watts_source"] = "strategy_command"
            item["command_source"] = "strategie"
            item["last_strategy_command"] = used_command
            item["strategy_error"] = None
            item["strategy_throttled"] = False
            item["strategy_next_update_seconds"] = POWERSTREAM_STRATEGY_MIN_INTERVAL_SECONDS

    async def _async_send_powerstream_watts(self, serial: str, watts: int) -> dict[str, Any]:
        device = self._powerstream(serial)
        watts = max(0, min(watts, int(device.get("max_watts", watts))))
        commands = _powerstream_command_candidates(device.get("command"), watts)
        if self.dry_run:
            return commands[0]
        errors: list[str] = []
        for command in commands:
            try:
                await self.ecoflow.set_device_command(serial, command)
            except EcoFlowApiError as err:
                errors.append(str(err))
                if "1008" not in str(err):
                    raise
                continue
            return command
        raise EcoFlowApiError("; ".join(errors))

    def _with_powerstream_target(
        self, serial: str, watts: int, source: str
    ) -> dict[str, Any]:
        data = dict(self.data or {})
        powerstreams = {
            key: dict(value) for key, value in (data.get("powerstreams") or {}).items()
        }
        item = dict(powerstreams.get(serial, {}))
        item["target_watts"] = float(watts)
        item["raw_target_watts"] = float(watts * 10)
        item["target_watts_source"] = "command"
        item["command_source"] = source
        powerstreams[serial] = item
        data["powerstreams"] = powerstreams
        data["last_powerstream_source"] = source
        data["powerstream_export_w"] = self._tracked_powerstream_export(
            powerstreams=powerstreams
        )
        return data

    async def async_check_ecoflow_api(self) -> None:
        """Manually validate EcoFlow API credentials and device-list access."""
        data = dict(self.data or {})
        errors = dict(data.get("errors") or {})
        try:
            response = await self.ecoflow.get_devices()
            serials = _extract_serials(response)
        except Exception as err:  # noqa: BLE001
            errors["ecoflow_api"] = str(err)
            data.update(
                {
                    "errors": errors,
                    "status": "EcoFlow API fout",
                    "last_action": f"EcoFlow API controle mislukt: {err}",
                }
            )
        else:
            errors.pop("ecoflow_api", None)
            data.update(
                {
                    "ecoflow_devices": serials,
                    "errors": errors,
                    "status": "ok" if not errors else f"{len(errors)} bron(nen) met fout",
                    "last_action": f"EcoFlow API ok, {len(serials)} apparaat/apparaten gevonden",
                }
            )
        self.async_set_updated_data(data)

    async def async_refresh_prices_now(self) -> None:
        """Manually fetch day-ahead prices."""
        data = dict(self.data or {})
        errors = dict(data.get("errors") or {})
        settings = {**self.entry.data, **self.entry.options}
        try:
            prices = await self._async_fetch_prices(settings)
        except Exception as err:  # noqa: BLE001
            errors["prices"] = str(err)
            data.update(
                {
                    "errors": errors,
                    "status": "prijsfeed fout",
                    "last_action": f"Prijzen ophalen mislukt: {err}",
                }
            )
        else:
            errors.pop("prices", None)
            data.update(
                {
                    "prices": prices,
                    "price_now": current_price(prices, dt_util.now()),
                    "price_bands": price_bands(prices),
                    "price_summary": price_summary(prices, dt_util.now()),
                    "errors": errors,
                    "status": "ok" if not errors else f"{len(errors)} bron(nen) met fout",
                    "last_action": f"Prijzen opgehaald, {len(prices)} uurrecords",
                }
            )
        self.async_set_updated_data(data)

    async def async_daily_price_refresh(self) -> None:
        """Fetch prices for the next day at the scheduled 15:00 refresh."""
        await self.async_refresh_prices_now()

    async def _async_fetch_prices(self, settings: dict[str, Any]) -> list[dict[str, Any]]:
        source = settings.get(CONF_PRICE_SOURCE, DEFAULT_PRICE_SOURCE)
        provider = settings.get(CONF_PRICE_PROVIDER, DEFAULT_PRICE_PROVIDER)
        interval = settings.get(CONF_PRICE_INTERVAL, DEFAULT_PRICE_INTERVAL)
        surcharge = float(settings.get(CONF_PRICE_SURCHARGE, DEFAULT_PRICE_SURCHARGE))
        if settings.get(CONF_PRICE_URL):
            return await fetch_prices(self.session, settings[CONF_PRICE_URL], surcharge)
        today = dt_util.now().date()
        if source == "energyzero":
            incl_vat = bool(settings.get(CONF_PRICE_INCL_VAT, DEFAULT_PRICE_INCL_VAT))
            record_keys = ("base_with_vat", "base") if incl_vat else ("base", "base_with_vat")
            prices: list[dict[str, Any]] = []
            for day in (today, today + timedelta(days=1)):
                prices.extend(
                    await fetch_prices(
                        self.session,
                        energyzero_url(day, interval),
                        surcharge,
                        record_keys,
                    )
                )
            return prices
        if source == "epexspot":
            prices: list[dict[str, Any]] = []
            for day in (today, today + timedelta(days=1)):
                prices.extend(await fetch_prices(self.session, epexspot_url(day), surcharge))
            return prices
        return await fetch_prices(self.session, epexprijzen_url(provider, interval), surcharge)

    async def async_apply_strategy(self) -> None:
        """Apply the currently selected simple price strategy."""
        price_now = (self.data or {}).get("price_now")
        bands = (self.data or {}).get("price_bands") or {}
        solar_power = float((self.data or {}).get("corrected_solar_power") or 0)
        forecast_solar_power = float((self.data or {}).get("forecast_solar_power") or 0)

        if self.strategy == STRATEGY_IDLE:
            for device in self.settings.get(CONF_POWERSTREAMS, []):
                serial = device.get("serial")
                if serial and "VUL_HIER" not in serial:
                    await self.async_set_powerstream_watts(serial, 0, "strategie uit")
            for device in self.settings.get(CONF_SMART_PLUGS, []):
                serial = device.get("serial")
                if serial and "VUL_HIER" not in serial:
                    await self.async_set_smart_plug(serial, False)
            self.async_set_updated_data(
                {**(self.data or {}), "last_action": "strategie uit"}
            )
            return

        if self.powerstream_strategies:
            await self._async_apply_strategy_groups(
                price_now,
                bands,
                solar_power,
                POWERSTREAM_STRATEGY_SELF_USE,
            )
        elif price_now is not None and self.strategy != STRATEGY_IDLE:
            default_strategy = {
                STRATEGY_SELF_USE: POWERSTREAM_STRATEGY_SELF_USE,
                STRATEGY_EXPORT: POWERSTREAM_STRATEGY_TRADING,
                STRATEGY_BUFFER_50: POWERSTREAM_STRATEGY_BUFFER_50,
            }.get(self.strategy, POWERSTREAM_STRATEGY_SELF_USE)
            await self._async_apply_strategy_groups(
                price_now,
                bands,
                solar_power,
                default_strategy,
            )

        for device in self.settings.get(CONF_SMART_PLUGS, []):
            serial = device.get("serial")
            if serial and "VUL_HIER" not in serial:
                plug_on = self._smart_plug_target_state(
                    device, solar_power, forecast_solar_power
                )
                await self.async_set_smart_plug(serial, plug_on)

    async def _async_apply_strategy_groups(
        self,
        price_now: float | None,
        bands: dict[str, float | None],
        solar_power: float,
        default_strategy: str,
    ) -> None:
        """Apply PowerStream strategy through the same throttled path as polling."""
        data = dict(self.data or {})
        powerstreams = {
            str(key): dict(value)
            for key, value in (data.get("powerstreams") or {}).items()
            if isinstance(value, dict)
        }
        errors = dict(data.get("errors") or {})
        await self._async_apply_group_strategies(
            powerstreams,
            price_now,
            bands,
            solar_power,
            errors,
            default_strategy,
        )
        throttled = [
            item for item in powerstreams.values() if item.get("strategy_throttled")
        ]
        failed = [
            item for item in powerstreams.values() if item.get("strategy_error")
        ]
        last_strategy_command = next(
            (
                item.get("last_strategy_command")
                for item in powerstreams.values()
                if item.get("last_strategy_command")
            ),
            data.get("last_powerstream_command"),
        )
        data.update(
            {
                "powerstreams": powerstreams,
                "errors": errors,
                "powerstream_export_w": self._tracked_powerstream_export(
                    powerstreams=powerstreams
                ),
                "status": "ok" if not errors else f"{len(errors)} bron(nen) met fout",
                "last_powerstream_command": last_strategy_command,
                "last_powerstream_error": failed[0].get("strategy_error")
                if failed
                else None,
                "last_action": (
                    "strategie wacht op 10-minuten begrenzing"
                    if throttled
                    else "strategie-command faalde"
                    if failed
                    else "strategie toegepast"
                ),
            }
        )
        self.async_set_updated_data(data)

    async def async_apply_best_scenario(self) -> None:
        """Select and apply the currently best simulated scenario."""
        scenario = best_scenario((self.data or {}).get("scenarios", {}), {})
        key = scenario.get("key")
        strategy_map = {
            "self_use": (STRATEGY_SELF_USE, POWERSTREAM_STRATEGY_SELF_USE),
            "trading": (STRATEGY_EXPORT, POWERSTREAM_STRATEGY_TRADING),
            "buffer_50": (STRATEGY_BUFFER_50, POWERSTREAM_STRATEGY_BUFFER_50),
        }
        if key not in strategy_map:
            self.async_set_updated_data(
                {**(self.data or {}), "last_action": "geen toepasbaar advies"}
            )
            return
        if not scenario_is_actionable(scenario):
            self.async_set_updated_data(
                {
                    **(self.data or {}),
                    "last_action": f"advies wacht: {scenario.get('reason', 'geen actie nodig')}",
                }
            )
            return
        global_strategy, group_strategy = strategy_map[str(key)]
        self.strategy = global_strategy
        for device in self.settings.get(CONF_POWERSTREAMS, []):
            serial = device.get("serial")
            if serial and "VUL_HIER" not in serial:
                self.powerstream_strategies[str(serial)] = group_strategy
        await self.async_apply_strategy()
        strategy_action = (self.data or {}).get("last_action")
        last_action = (
            f"advies gestart: {scenario.get('label', key)}"
            if strategy_action == "strategie toegepast"
            else f"advies gekozen: {scenario.get('label', key)}; {strategy_action}"
        )
        self.async_set_updated_data(
            {
                **(self.data or {}),
                "last_action": last_action,
            }
        )

    async def async_set_smart_plug(self, serial: str, on: bool) -> None:
        """Set a configured EcoFlow smart plug on or off."""
        device = self._smart_plug(serial)
        template = device["on_command"] if on else device["off_command"]
        command = render_template_dict(template, {"on": on})
        timestamp = dt_util.utcnow().isoformat()
        self.smart_plug_last_state[str(serial)] = on
        self.smart_plug_last_state_at[str(serial)] = timestamp
        if self.dry_run:
            self._publish_smart_plug_runtime_state(
                serial, on, timestamp, f"dry-run plug {serial} -> {on}"
            )
            return
        await self.ecoflow.set_device_command(serial, command)
        self._publish_smart_plug_runtime_state(
            serial, on, timestamp, f"plug {serial} -> {on}"
        )

    def _publish_smart_plug_runtime_state(
        self, serial: str, on: bool, timestamp: str, last_action: str
    ) -> None:
        data = self.data or {}
        smart_plugs = dict(data.get("smart_plugs", {}))
        current = dict(smart_plugs.get(str(serial), {}))
        current["last_command"] = on
        current["last_command_at"] = timestamp
        smart_plugs[str(serial)] = current
        self.async_set_updated_data(
            {**data, "smart_plugs": smart_plugs, "last_action": last_action}
        )

    async def _async_apply_smart_plug_schedule_now(
        self,
        settings: dict[str, Any],
        solar_power: float,
        forecast_solar_power: float,
    ) -> None:
        now = dt_util.now()
        for device in settings.get(CONF_SMART_PLUGS, []):
            serial = device.get("serial")
            if not serial or "VUL_HIER" in serial:
                continue
            scheduled = self._smart_plug_scheduled_state(device, now)
            desired: bool | None
            if scheduled is not None:
                desired = scheduled
            elif self.strategy != STRATEGY_IDLE:
                desired = self._smart_plug_target_state(
                    device,
                    solar_power,
                    forecast_solar_power,
                )
            else:
                continue
            if desired is None:
                continue
            current = self.smart_plug_last_state.get(str(serial))
            if current is not None and current == desired:
                continue
            await self.async_set_smart_plug(str(serial), desired)

    def _smart_plug_scheduled_state(
        self,
        device: dict[str, Any],
        now: dt_datetime,
    ) -> bool | None:
        if not device.get("schedule_enabled"):
            return None
        start_time = _parse_time_value(device.get("schedule_on"))
        end_time = _parse_time_value(device.get("schedule_off"))
        if start_time is None or end_time is None:
            return None
        if start_time == end_time:
            return None

        current = now.time()
        if start_time < end_time:
            return start_time <= current < end_time
        return current >= start_time or current < end_time

    def _smart_plug_target_state(
        self,
        device: dict[str, Any],
        solar_power: float,
        forecast_solar_power: float,
    ) -> bool:
        scheduled = self._smart_plug_scheduled_state(device, dt_util.now())
        if scheduled is not None:
            return scheduled
        combined_solar = max(float(solar_power or 0), float(forecast_solar_power or 0))
        return combined_solar >= self.solar_plug_threshold_watts

    def _powerstream(self, serial: str) -> dict[str, Any]:
        for device in self.settings.get(CONF_POWERSTREAMS, []):
            if device.get("serial") == serial:
                return device
        raise ValueError(f"Unknown PowerStream serial: {serial}")

    def _smart_plug(self, serial: str) -> dict[str, Any]:
        for device in self.settings.get(CONF_SMART_PLUGS, []):
            if device.get("serial") == serial:
                return device
        raise ValueError(f"Unknown smart plug serial: {serial}")

    def _tracked_powerstream_export(
        self,
        phase: str | None = None,
        powerstreams: dict[str, dict[str, Any]] | None = None,
    ) -> float:
        total = 0.0
        for device in self.settings.get(CONF_POWERSTREAMS, []):
            serial = device.get("serial")
            if not serial:
                continue
            if phase and str(device.get("phase", "")).lower() != phase:
                continue
            item = (powerstreams or {}).get(serial, {})
            total += float(
                self.powerstream_targets.get(
                    serial,
                    item.get("target_watts") or 0,
                )
            )
        return total


def _extract_values(response: dict[str, Any]) -> dict[str, Any]:
    data = response.get("data")
    if isinstance(data, dict):
        if isinstance(data.get("quotas"), list):
            return _quota_list_to_values(data["quotas"])
        if isinstance(data.get("quotas"), dict):
            return _flatten_value_dict(data["quotas"])
        return _flatten_value_dict(data)
    if isinstance(data, list):
        return _quota_list_to_values(data)
    return {}


def _response_debug(response: dict[str, Any]) -> dict[str, Any]:
    data = response.get("data")
    return {
        "code": response.get("code"),
        "message": response.get("message"),
        "top_level_keys": sorted(response.keys()),
        "data_type": type(data).__name__,
        "data_keys": sorted(data.keys())[:40] if isinstance(data, dict) else [],
        "data_length": len(data) if isinstance(data, list) else None,
    }


def _quota_list_to_values(records: list[Any]) -> dict[str, Any]:
    values: dict[str, Any] = {}
    for item in records:
        if not isinstance(item, dict):
            continue
        key = _first_text(item, ("name", "key", "quota", "param", "code", "id"))
        if not key:
            continue
        if "value" in item:
            values[key] = item["value"]
        elif "val" in item:
            values[key] = item["val"]
        elif "data" in item:
            values[key] = item["data"]
    return values


def _flatten_value_dict(data: dict[str, Any]) -> dict[str, Any]:
    values: dict[str, Any] = {}
    _flatten_values(data, "", values)
    return values


def _flatten_values(data: Any, prefix: str, values: dict[str, Any]) -> None:
    if isinstance(data, dict):
        if "value" in data and prefix:
            values[prefix] = data["value"]
            return
        for key, value in data.items():
            child_key = f"{prefix}.{key}" if prefix else str(key)
            _flatten_values(value, child_key, values)
        return
    if isinstance(data, list):
        quota_values = _quota_list_to_values(data)
        if quota_values:
            for key, value in quota_values.items():
                values[f"{prefix}.{key}" if prefix else key] = value
            return
        for index, value in enumerate(data):
            child_key = f"{prefix}[{index}]" if prefix else f"[{index}]"
            _flatten_values(value, child_key, values)
        return
    if prefix:
        values[prefix] = data


def _first_number_or_match(
    values: dict[str, Any], keys: tuple[str, ...], default: float = 0.0
) -> float:
    value, _source = _first_number_or_match_with_source(values, keys, default)
    return value


def _first_number_or_match_with_source(
    values: dict[str, Any], keys: tuple[str, ...], default: float = 0.0
) -> tuple[float, str]:
    exact = _first_number(values, keys, None)
    if exact is not None:
        source = next((key for key in keys if _first_number(values, (key,), None) is not None), "telemetry")
        return exact, str(source)
    for key, value in values.items():
        normalized = key.lower().replace("_", "").replace("-", "")
        if "watt" not in normalized and "power" not in normalized:
            continue
        if "input" in normalized or "pv" in normalized or "solar" in normalized:
            continue
        if not any(part in normalized for part in ("output", "out", "grid", "inv", "permanent", "ac")):
            continue
        if isinstance(value, dict) and "value" in value:
            value = value["value"]
        try:
            return float(value), str(key)
        except (TypeError, ValueError):
            continue
    return default, "stored_target"


def _needs_battery_power_fallback(values: dict[str, Any]) -> bool:
    power_fields = _battery_live_power_fields(values)
    if not power_fields:
        return True
    if len(values) <= 3 and not any(abs(value) > 0 for value in power_fields):
        return True
    if not _has_directional_power_field(values, "charge"):
        return True
    if not _has_directional_power_field(values, "discharge"):
        return True
    return False


def _battery_live_power_fields(values: dict[str, Any]) -> list[float]:
    fields: list[float] = []
    for key, value in values.items():
        normalized = key.lower().replace("_", "").replace("-", "").replace(".", "")
        if not _is_battery_live_power_key(normalized):
            continue
        numeric = _coerce_float(value)
        if numeric is not None:
            fields.append(numeric)
    return fields


def _has_directional_power_field(values: dict[str, Any], direction: str) -> bool:
    parts = (
        ("input", "charge", "chg", "powin", "wattsin", "acin", "dcin", "pvin")
        if direction == "charge"
        else ("output", "discharge", "dsg", "powout", "wattsout", "acout", "dcout", "invout")
    )
    for key, value in values.items():
        normalized = key.lower().replace("_", "").replace("-", "").replace(".", "")
        if not _is_battery_live_power_key(normalized):
            continue
        if not any(part in normalized for part in parts):
            continue
        if _coerce_float(value) is not None:
            return True
    return False


def _is_battery_live_power_key(normalized: str) -> bool:
    if not any(part in normalized for part in ("watt", "power", "pow")):
        return False
    return not any(
        part in normalized
        for part in (
            "max",
            "min",
            "limit",
            "design",
            "fullenergy",
            "remain",
            "remtime",
            "standby",
            "soc",
            "soh",
            "temp",
        )
    )


def _coerce_float(value: Any) -> float | None:
    if isinstance(value, dict) and "value" in value:
        value = value["value"]
    try:
        return float(str(value).replace(",", "."))
    except (TypeError, ValueError):
        return None


def _first_number(
    values: dict[str, Any], keys: tuple[str, ...], default: float | None = 0.0
) -> float | None:
    for key in keys:
        value = values.get(key)
        if value is None:
            continue
        try:
            return float(value)
        except (TypeError, ValueError):
            continue
    return default


def _first_text(values: dict[str, Any], keys: tuple[str, ...]) -> str | None:
    for key in keys:
        value = values.get(key)
        if value is not None:
            return str(value)
    return None


def _battery_min_soc(batteries: dict[str, Any]) -> float | None:
    values: list[float] = []
    for item in batteries.values():
        battery_values = item.get("values", {}) if isinstance(item, dict) else {}
        soc = _battery_soc_value(battery_values)
        if soc is not None:
            values.append(float(soc))
    if not values:
        return None
    return min(values)


def _scenario_input_warnings(
    price_now: float | None,
    cheap: float | None,
    expensive: float | None,
    battery_soc: float | None,
) -> list[str]:
    warnings: list[str] = []
    if price_now is None:
        warnings.append("prijs ontbreekt")
    if cheap is None or expensive is None:
        warnings.append("prijsgrenzen ontbreken")
    if battery_soc is None:
        warnings.append("accu-SoC onbekend")
    return warnings


def _scenario_reason(reason: str, warnings: list[str]) -> str:
    if not warnings:
        return reason
    return f"input beperkt: {', '.join(warnings)}; {reason}"


def _battery_soc_for_serial(
    batteries: dict[str, Any], serial: str | None
) -> float | None:
    if not serial:
        return None
    item = batteries.get(str(serial)) or {}
    return _battery_soc_value(item.get("values", {}))


def _battery_free_wh_for_serial(
    batteries: dict[str, Any], serial: str | None, battery_name: str | None
) -> float | None:
    if not serial:
        return None
    item = batteries.get(str(serial)) or {}
    values = item.get("values", {}) if isinstance(item, dict) else {}
    soc = _battery_soc_value(values)
    capacity = _battery_capacity_wh(values, battery_name)
    if soc is None or capacity is None:
        return None
    return round(max(0.0, capacity * (100.0 - float(soc)) / 100.0), 0)


def _battery_capacity_wh(values: dict[str, Any], battery_name: str | None) -> float | None:
    capacity = _first_number_or_match(
        values,
        (
            "cmsBattFullEnergy",
            "ems.fullEnergy",
            "pd.fullEnergy",
            "fullEnergy",
            "fullEnergyWh",
            "batteryFullEnergy",
            "bmsDesignCap",
            "bms_emsStatus.designCap",
            "bms_bmsStatus.designCap",
        ),
        0,
    )
    if capacity <= 0:
        normalized = str(battery_name or "").lower().replace(" ", "")
        if "pro3" in normalized or "delta3" in normalized:
            return 8192.0
        if "pro" in normalized:
            return 7200.0
        return None
    if capacity < 100:
        capacity *= 1000
    return round(capacity, 0)


def _battery_name(settings: dict[str, Any], serial: str | None) -> str | None:
    if not serial:
        return None
    for device in settings.get(CONF_BATTERIES, []):
        if str(device.get("serial")) == str(serial):
            return str(device.get("name") or serial)
    return str(serial)


def _fallback_battery_serial(
    configured_batteries: list[dict[str, Any]], index: int
) -> str | None:
    if index >= len(configured_batteries):
        return None
    serial = configured_batteries[index].get("serial")
    return str(serial) if serial else None


def _expected_savings(price_now: float | None, weather: dict[str, Any]) -> float:
    price = float(price_now or 0)
    solar_wh_kwp = float(weather.get("solar_next_24h_wh_kwp") or 0)
    return round((solar_wh_kwp / 1000) * price, 2)


def _powerstream_command_candidates(
    configured_command: Any, watts: int
) -> list[dict[str, Any]]:
    deciwatts = int(watts * 10)
    template = configured_command if isinstance(configured_command, dict) else {}
    rendered = (
        render_template_dict(template, {"watts": watts, "deciwatts": deciwatts})
        if template
        else {}
    )
    normalized = _normalize_powerstream_command(rendered, watts, deciwatts)
    compact_deciwatt = {
        "cmdCode": "WN511_SET_PERMANENT_WATTS_PACK",
        "params": {"permanentWatts": deciwatts},
    }
    full_deciwatt = {
        "id": 1,
        "version": "1.0",
        "cmdCode": "WN511_SET_PERMANENT_WATTS_PACK",
        "params": {"permanentWatts": deciwatts},
    }
    compact_watt = {
        "cmdCode": "WN511_SET_PERMANENT_WATTS_PACK",
        "params": {"permanentWatts": watts},
    }
    full_watt = {
        "id": 1,
        "version": "1.0",
        "cmdCode": "WN511_SET_PERMANENT_WATTS_PACK",
        "params": {"permanentWatts": watts},
    }
    candidates: list[dict[str, Any]] = []
    for command in (normalized, compact_deciwatt, full_deciwatt, compact_watt, full_watt):
        if command and command not in candidates:
            candidates.append(command)
    return candidates or [full_deciwatt]


def _normalize_powerstream_command(
    command: dict[str, Any], watts: int, deciwatts: int
) -> dict[str, Any]:
    normalized = dict(command)
    if normalized.get("operateType") == "WN511_SET_PERMANENT_WATTS_PACK":
        normalized.pop("operateType", None)
        normalized.pop("moduleType", None)
        normalized["cmdCode"] = "WN511_SET_PERMANENT_WATTS_PACK"
    if normalized.get("cmdCode") == "WN511_SET_PERMANENT_WATTS_PACK":
        params = dict(normalized.get("params") or {})
        permanent_watts = params.get("permanentWatts")
        if permanent_watts in (None, watts):
            params["permanentWatts"] = deciwatts
        normalized["params"] = params
    return normalized


def _battery_soc_value(values: dict[str, Any]) -> float | None:
    soc = _first_number(
        values,
        (
            "cmsBattSoc",
            "bmsBattSoc",
            "pd.soc",
            "ems.soc",
            "bms.soc",
            "bms_emsStatus.soc",
            "bms_bmsStatus.soc",
            "soc",
            "socLevel",
            "batteryLevel",
        ),
        None,
    )
    if soc is not None:
        return max(0.0, min(float(soc), 100.0))
    for key, value in values.items():
        normalized = key.lower().replace("_", "").replace("-", "")
        if "soc" not in normalized and "batterylevel" not in normalized:
            continue
        if _is_soc_limit_or_setting(normalized):
            continue
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            continue
        if 0 <= numeric <= 100:
            return numeric
    return None


def _is_soc_limit_or_setting(normalized_key: str) -> bool:
    blocked_parts = (
        "min",
        "max",
        "backup",
        "reserve",
        "generator",
        "oil",
        "alwayson",
        "conflict",
        "limit",
        "start",
        "stop",
    )
    return any(part in normalized_key for part in blocked_parts)


def _coerce_homewizard_meters(
    items: list[dict[str, Any]] | Any,
) -> list[dict[str, Any]]:
    """Drop manual HomeWizard entries when HA-imported entries exist for same role."""
    if not isinstance(items, list):
        return []

    ha_roles: set[str] = set()
    seen_ha: set[str] = set()
    output: list[dict[str, Any]] = []

    for item in items:
        if not isinstance(item, dict):
            continue
        if item.get("source") != "homeassistant":
            continue
        role = _coerce_homewizard_role(item)
        ha_roles.add(role)
        key = f"{role}:{item.get('device_id', '')}"
        if key in seen_ha:
            continue
        seen_ha.add(key)
        output.append(item)

    for item in items:
        if not isinstance(item, dict) or item.get("source") == "homeassistant":
            continue
        role = _coerce_homewizard_role(item)
        if role in ha_roles:
            continue
        output.append(item)

    return output


def _coerce_homewizard_role(item: dict[str, Any]) -> str:
    explicit = str(item.get("role") or "").strip()
    if explicit in (HOMEWIZARD_ROLE_SOLAR_TOTAL, HOMEWIZARD_ROLE_GRID_METER):
        return explicit
    return _infer_homewizard_role_from_text(
        item.get("name"),
        item.get("model"),
        item.get("host"),
        item.get("device_id"),
    )


def _infer_homewizard_role_from_text(*parts: Any) -> str:
    text = " ".join(str(part or "") for part in parts).lower()
    compact = text.replace("_", " ").replace("-", " ")
    if "p1" in compact or "netmeter" in compact or "energy socket" in compact:
        return HOMEWIZARD_ROLE_GRID_METER
    if "p1 meter" in compact or "p1meter" in compact:
        return HOMEWIZARD_ROLE_GRID_METER
    return DEFAULT_HOMEWIZARD_ROLE


def _extract_serials(response: dict[str, Any]) -> list[str]:
    serials: set[str] = set()

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {"sn", "serial", "serialNumber", "deviceSn"} and item:
                    serials.add(str(item))
                else:
                    walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)

    walk(response.get("data", response))
    return sorted(serials)


def _parse_time_value(value: Any) -> dt_datetime.time | None:
    if value is None:
        return None
    candidate = str(value).strip()
    if not candidate:
        return None
    try:
        return dt_datetime.strptime(candidate, "%H:%M").time()
    except ValueError:
        return None
